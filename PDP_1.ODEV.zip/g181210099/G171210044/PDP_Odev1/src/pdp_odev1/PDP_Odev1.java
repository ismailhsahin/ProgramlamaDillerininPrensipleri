/**
*
* @author Nisanur Karatepe - nisanur.karatepe@ogr.sakarya.edu.tr
* @since 05/03/2020
* <p>
* Dosyanin okunup istenenlerin sayildiği program.
* </p>
*/

package pdp_odev1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author KARATEPE
 */
public class PDP_Odev1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        File textFile = new File("icerik.txt");
        Scanner in = new Scanner(textFile);

        StringBuffer stringBuffer ;
        stringBuffer = new StringBuffer();
        
        while(in.hasNextLine())
        {
         stringBuffer.append(in.nextLine()).append("\n");
        }
        
        String regex = "[aeıioöuüAEIİOÖUÜ]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(stringBuffer);
        int sesli_harf_sayisi = 0;
        while(matcher.find()) {
            sesli_harf_sayisi++;
        }
        
        regex = "\\s+";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(stringBuffer);
        int kelime_sayisi = 0;
        while(matcher.find()) {
            kelime_sayisi++;
        }
        
        
        regex = "([a-z0-9_.-]+)@([a-z0-9_.-]+[a-z])+[.]+([a-z0-9_.-])";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(stringBuffer);
        int mail_sayisi = 0;
        while(matcher.find()) {
            mail_sayisi++;
            stringBuffer.delete(matcher.start(),matcher.end());
            matcher = pattern.matcher(stringBuffer);
        }
        
        StringBuffer web_siteleri ;
        web_siteleri = new StringBuffer();
        
        regex = "(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http)?(https://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(stringBuffer);
        int web_sayisi = 0;
        while(matcher.find()) {
            web_siteleri.append(stringBuffer.substring(matcher.start(), matcher.end())).append("\n");
            stringBuffer.delete(matcher.start(),matcher.end());
            matcher = pattern.matcher(stringBuffer);
        }

        regex = "\\b.com|.edu|.net|.org|.com.tr|.edu.tr|.net.tr|.org.tr\\b";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(web_siteleri);
        while(matcher.find()) {
            web_sayisi++;
        }
        
        
        regex = "[.]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(stringBuffer);
        int cumle_sayisi = 0;
        while(matcher.find()) {
            cumle_sayisi++;
        }
        
        
        System.out.println("Toplam sesli harf sayısı: " + sesli_harf_sayisi);
        System.out.println("Toplam kelime sayısı: " + kelime_sayisi);
        System.out.println("Toplam cümle sayısı: " + cumle_sayisi);
        System.out.println("Toplam mail sayısı: " + mail_sayisi);
        System.out.println("Toplam web sayısı: " + web_sayisi);
        
    }
}
